This example creates an SDL window and renderer, loads a texture from a .png
file, and then draws it, scaling it up and down.

